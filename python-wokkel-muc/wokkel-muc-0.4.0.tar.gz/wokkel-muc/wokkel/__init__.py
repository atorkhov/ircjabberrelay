# Copyright (c) 2003-2007 Ralph Meijer
# See LICENSE for details

"""
Wokkel.

Support library for Twisted applications using XMPP protocols.
"""
